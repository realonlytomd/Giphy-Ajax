# Button Triggered AJAX

## File

* [`button-triggered-ajax`](Unsolved/button-triggered-ajax.html)

## Instructions

* Using the sample code you've just been given and the code comments as a guide, re-create the functionality you just observed.

* Your final application should trigger Gifs about your celebrity/author to appear.
